-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: workplace
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `assigned_user` int DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `status` enum('Pending','In Progress','Completed','Delayed') DEFAULT 'Pending',
  `priority` enum('Low','Medium','High') DEFAULT 'Medium',
  `project_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `assigned_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status_update_location` text,
  `status_updated_at` datetime DEFAULT NULL,
  `feedback` text,
  PRIMARY KEY (`id`),
  KEY `assigned_user` (`assigned_user`),
  KEY `project_id` (`project_id`),
  KEY `created_by` (`created_by`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_user`) REFERENCES `users` (`id`),
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  CONSTRAINT `tasks_ibfk_4` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (10,'Work on Electricity','please',5,'2025-05-22 13:43:00','2025-05-22 16:43:00','Completed','Medium',2,'Admin',NULL,'2025-05-22 11:43:31','2025-06-02 12:56:50','https://maps.google.com/?q=-1.9514895269354173,30.059635218302347','2025-06-02 14:27:07','good yes'),(11,'Work with REG','Work with REG in countryside',5,'2025-05-22 16:40:00','2025-05-22 17:40:00','Completed','Medium',2,'Admin',NULL,'2025-05-22 14:40:21','2025-06-02 13:00:52','https://maps.google.com/?q=-1.951489838873415,30.059636561658458','2025-06-02 14:12:00','Great work! Task completed successfully.'),(12,'Work in Gicumbi','work on electricity there fast',5,'2025-06-02 14:29:00','2025-06-02 17:00:00','In Progress','High',2,'admin',NULL,'2025-06-02 12:29:28','2025-06-02 13:12:30','https://maps.google.com/?q=-1.9515112,30.0596517','2025-06-02 14:31:32','Please review and make necessary adjustments.'),(13,'Task 101','please',5,'2025-07-31 14:43:00','2025-08-01 22:43:00','Pending','Medium',2,'admin',NULL,'2025-06-02 12:43:30','2025-06-02 12:43:30',NULL,NULL,NULL),(14,'TASK 104-1','work on reg',5,'2025-06-01 14:44:00','2025-06-01 18:44:00','Pending','Medium',2,'admin',NULL,'2025-06-02 12:44:35','2025-06-02 12:44:35',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-02 17:42:57
